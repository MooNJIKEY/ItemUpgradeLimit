# Item Upgrade Mod для Valheim

[English Version](README_EN.md)

Мод позволяет настраивать максимальный уровень улучшения предметов в Valheim.

## 🎯 Возможности

- **Настройка по категориям** - оружие, броня, щиты, инструменты
- **Индивидуальные настройки** - свой уровень для каждого предмета
- **Простая конфигурация** - через файл config
- **Обход ограничения уровня верстака** - улучшайте предметы независимо от уровня верстака
- **Полная совместимость** с Valheim 0.221.4+

## 📦 Установка

### Через мод-менеджер (рекомендуется)

1. Установите [r2modman](https://thunderstore.io/package/ebkr/r2modman/) или другой мод-менеджер
2. Найдите `ItemUpgradeMod` в списке модов
3. Нажмите "Install"
4. Запустите игру через мод-менеджер

### Ручная установка

1. Установите [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)
2. Скачайте последний релиз мода
3. Распакуйте в `BepInEx/plugins/ItemUpgradeMod/`
4. Запустите игру

## ⚙️ Настройка

После первого запуска откройте файл:
```
BepInEx/config/com.valheim.itemupgrademod.cfg
```

### Пример конфигурации

```ini
[Item Categories]
WeaponMaxLevel = 10      # Оружие
ArmorMaxLevel = 10       # Броня
ShieldMaxLevel = 10      # Щиты
ToolMaxLevel = 10        # Инструменты
DefaultMaxLevel = 8      # Остальное

[Custom Items]
# Формат: ИмяПредмета:Уровень
ItemLevels = SwordIron:15,HelmetBronze:12
```

## 🎮 Использование

1. Настройте уровни в конфиге
2. Перезапустите игру
3. Создайте/улучшайте предметы
4. Наслаждайтесь новыми уровнями!

**Важно**: Мод автоматически обходит ограничение уровня верстака, поэтому вы можете улучшать предметы до настроенного максимального уровня независимо от уровня вашего верстака.

## 📋 Названия предметов

См. [example_config.cfg](ItemUpgradeMod/example_config.cfg) для полного списка.

## 🐛 Проблемы?

[Создайте Issue](https://github.com/MooNJIKEY/ItemUpgradeLimit/issues) на GitHub.

## 📜 Лицензия

MIT License

## 🙏 Благодарности

- BepInEx Team
- Valheim Community
